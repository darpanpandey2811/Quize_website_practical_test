const questions=[
    {
         question: "What is the full form of “AI”?",
         answers:[
            {text:"Artificially Intelligent",correct:false},
            {text:"Artificial Intelligence",correct:true},
            {text:"Artificially Intelligence",correct:false},
            {text:"Advanced Intelligence",correct:false}

        ]
    },
    {
        question: "Who is the inventor of Artificial Intelligence?",
        answers:[
            {text:"Geoffrey Hinton",correct:false},
            {text:"Andrew Ng",correct:true},
            {text:"John McCarthy",correct:true},
            {text:"Jürgen Schmidhuber",correct:false}
        ]
    },
    {
        question: "Which of the following is the branch of Artificial Intelligence?",
        answers:[
            {text:"Machine Learning",correct:true},
            {text:"Cyber forensics",correct:true},
            {text:"Full-Stack Developer",correct:true},
            {text:"Network Design",correct:false}
        ]
    }
];

const questionElement= document.getElementById("question");
const answerButton= document.getElementById("answer-button");
const nextButton= document.getElementById("next-btn");

let currentQuestionIndex=0;
let score=0;

function startQuiz(){
    currentQuestionIndex=0;
    score=0;
    nextButton.innerHTML="Next";
    showQuestion();
}

function showQuestion()
{
    let currentQuestion=questions[currentQuestionIndex];
    let questionNo=currentQuestionIndex+1;
    questionElement.innerHTML=questionNo+". "+currentQuestion.question;

    currentQuestion.answers.forEach(answer=>{
        const button=document.createElement("button");
        button.innerHTML=answer.text;
        button.classList.add("btn");
        answerButton.appendChild(button);

    })

}

startQuiz();