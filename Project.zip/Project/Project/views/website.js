const questions=[
    {
         question: "How can we write comment along with CSS code ?",
         answers:[
            {text:"/* a comment*/",correct:true},
            {text:"//a comment //",correct:false},
            {text:"/ a comment/",correct:false},
            {text:"<’a comment’>",correct:false}

        ]
    },
    {
        question: "Which CSS property is used to control the text size of an element ?",
        answers:[
            {text:"font-style",correct:false},
            {text:"text-size",correct:false},
            {text:"font-size",correct:true},
            {text:"text-style",correct:false}
        ]
    },
    {
        question: "How will you make all paragraph elements 'RED' in color ?",
        answers:[
            {text:"p.all{color:red;}",correct:false},
            {text:"p.all{color:#990000;}",correct:false},
            {text:"all.p{color:#998877;}",correct:false},
            {text:"2p{color:red;}",correct:true}
        ]
    }
];

const questionElement= document.getElementById("question");
const answerButton= document.getElementById("answer-buttons");
const nextButton= document.getElementById("next-btn");
const prevButton= document.getElementById("prev-btn");

let currentQuestionIndex=0;
let score=0;

function startQuiz(){
    currentQuestionIndex=0;
    score=0;
    nextButton.innerHTML="Next";
    prevButton.innerHTML="Previous";
    showQuestion();
}

function showQuestion()
{
    resetState();
    let currentQuestion=questions[currentQuestionIndex];
    let questionNo=currentQuestionIndex+1;
    questionElement.innerHTML=questionNo+". "+currentQuestion.question;

    currentQuestion.answers.forEach(answer=>{
        const button=document.createElement("button");
        button.innerHTML=answer.text;
        button.classList.add("btn");
        answerButton.appendChild(button);
        if(answer.correct){
            button.dataset.correct= answer.correct;
        }
        button.addEventListener("click",selectAnswer);
        nextButton.style.display="block";

    })

}

function resetState(){
    nextButton.style.display="none";
    while(answerButton.firstChild){
        answerButton.removeChild(answerButton.firstChild);
    }
}


function selectAnswer(e){
    const selectedBtn=e.target;
    const isCorrect=selectedBtn.dataset.correct==="true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }
    else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButton.children).forEach(button=>{
        if(button.dataset.correct==="true"){
            button.classList.add("correct");
        }
        button.disabled="true";
    });
   
}

function showScore(){
    resetState();
    questionElement.innerHTML=`You scored ${score} out of ${questions.length}!`
    nextButton.innerHTML="Play Again";
    nextButton.style.display="block";
}
function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex<questions.length){
        showQuestion();
    }
    else{
        showScore();
    }
}
function  handlePrevButton(){
    currentQuestionIndex--;
    showQuestion()
}

prevButton.addEventListener("click",()=>{
    if(currentQuestionIndex>0)
    {
        handlePrevButton();
    }
    else{
        startQuiz();
    }
})
nextButton.addEventListener("click",()=>{
    if(currentQuestionIndex<questions.length){
        handleNextButton();

    }
    else{
        startQuiz();
    }
}

)
startQuiz();